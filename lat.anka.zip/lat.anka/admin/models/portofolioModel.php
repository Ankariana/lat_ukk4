<?php
   
   class portofolioMoodel{

    public function __construct()
    {

    }
    
   }
